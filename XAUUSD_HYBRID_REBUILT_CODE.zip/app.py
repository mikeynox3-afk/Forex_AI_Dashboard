import os
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import streamlit as st
import plotly.graph_objects as go
import yfinance as yf
import feedparser

warnings.filterwarnings("ignore")

# ------------------------------------------------------------
# XAUUSD AI HYBRID RESEARCH DASHBOARD
# Research / education only. No broker connection or live orders.
# ------------------------------------------------------------

st.set_page_config(
    page_title="XAUUSD AI Hybrid Research",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.title("📊 XAUUSD AI Hybrid Research Dashboard")
st.caption(
    "শিক্ষামূলক মার্কেট রিসার্চ ও ভার্চুয়াল বিশ্লেষণ। "
    "এটি কোনো আর্থিক পরামর্শ নয় এবং কোনো real trade execute করে না।"
)

# ---------- Sidebar ----------
st.sidebar.header("Dashboard Settings")
period = st.sidebar.selectbox(
    "ডেটার সময়সীমা",
    ["5d", "7d", "1mo", "3mo", "6mo", "1y"],
    index=1,
)
interval = st.sidebar.selectbox(
    "মূল ডেটা Interval",
    ["5m", "15m", "30m", "60m", "1d"],
    index=0,
)
refresh_seconds = st.sidebar.selectbox(
    "Auto refresh (seconds)",
    [0, 60, 120, 300],
    index=1,
)
show_news = st.sidebar.checkbox("News Feed দেখাও", value=True)
show_raw = st.sidebar.checkbox("শেষের ডেটা টেবিল দেখাও", value=False)

if refresh_seconds > 0:
    try:
        from streamlit_autorefresh import st_autorefresh
        st_autorefresh(interval=refresh_seconds * 1000, key="xau_refresh")
    except Exception:
        st.sidebar.info("Auto-refresh package পাওয়া যায়নি; requirements.txt পরীক্ষা করো।")


# ---------- Data helpers ----------
@st.cache_data(ttl=60, show_spinner=False)
def download_market_data(selected_period: str, selected_interval: str) -> pd.DataFrame:
    tickers = ["XAUUSD=X", "GC=F"]
    for ticker in tickers:
        try:
            data = yf.download(
                ticker,
                period=selected_period,
                interval=selected_interval,
                auto_adjust=False,
                progress=False,
                threads=False,
            )
            if data is None or data.empty:
                continue

            # yfinance can return MultiIndex columns even for one ticker.
            if isinstance(data.columns, pd.MultiIndex):
                data.columns = [
                    col[0] if isinstance(col, tuple) else col
                    for col in data.columns
                ]

            data.columns = [str(col).strip().title() for col in data.columns]
            needed = ["Open", "High", "Low", "Close"]
            if not all(col in data.columns for col in needed):
                continue

            if "Volume" not in data.columns:
                data["Volume"] = 0.0

            data = data[["Open", "High", "Low", "Close", "Volume"]].copy()
            for col in data.columns:
                data[col] = pd.to_numeric(data[col], errors="coerce")

            data = data.dropna(subset=needed)
            data = data[~data.index.duplicated(keep="last")].sort_index()
            if not data.empty:
                data.attrs["ticker_used"] = ticker
                return data
        except Exception:
            continue
    return pd.DataFrame()


def calculate_indicators(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    close = out["Close"]
    high = out["High"]
    low = out["Low"]
    volume = out["Volume"].fillna(0)

    out["EMA_20"] = close.ewm(span=20, adjust=False).mean()
    out["EMA_50"] = close.ewm(span=50, adjust=False).mean()
    out["EMA_200"] = close.ewm(span=200, adjust=False).mean()

    delta = close.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.ewm(alpha=1 / 14, adjust=False, min_periods=14).mean()
    avg_loss = loss.ewm(alpha=1 / 14, adjust=False, min_periods=14).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    out["RSI"] = 100 - (100 / (1 + rs))
    out["RSI"] = out["RSI"].fillna(50)

    ema12 = close.ewm(span=12, adjust=False).mean()
    ema26 = close.ewm(span=26, adjust=False).mean()
    out["MACD"] = ema12 - ema26
    out["MACD_Signal"] = out["MACD"].ewm(span=9, adjust=False).mean()

    previous_close = close.shift(1)
    tr = pd.concat(
        [
            high - low,
            (high - previous_close).abs(),
            (low - previous_close).abs(),
        ],
        axis=1,
    ).max(axis=1)
    out["ATR"] = tr.ewm(alpha=1 / 14, adjust=False, min_periods=14).mean()
    out["Volatility"] = close.pct_change().rolling(20).std().fillna(0)

    avg_volume = volume.rolling(20).mean()
    out["Volume_Ratio"] = (
        volume / avg_volume.replace(0, np.nan)
    ).replace([np.inf, -np.inf], np.nan).fillna(1.0)

    candle_range = (high - low).replace(0, np.nan)
    buy_pressure = ((close - low) / candle_range).clip(0, 1)
    out["Estimated_Buy_Pressure"] = buy_pressure.fillna(0.5)
    out["Estimated_Sell_Pressure"] = (1 - out["Estimated_Buy_Pressure"])

    typical_price = (high + low + close) / 3
    cumulative_volume = volume.replace(0, np.nan).cumsum()
    out["VWAP"] = (
        (typical_price * volume).cumsum() / cumulative_volume
    ).replace([np.inf, -np.inf], np.nan)
    out["VWAP"] = out["VWAP"].fillna(close)

    middle = close.rolling(20).mean()
    std = close.rolling(20).std()
    out["BB_Upper"] = middle + 2 * std
    out["BB_Lower"] = middle - 2 * std

    return out.replace([np.inf, -np.inf], np.nan)


def resample_frame(df: pd.DataFrame, rule: str) -> pd.DataFrame:
    agg = {
        "Open": "first",
        "High": "max",
        "Low": "min",
        "Close": "last",
        "Volume": "sum",
    }
    result = df.resample(rule).agg(agg).dropna(subset=["Open", "High", "Low", "Close"])
    if result.empty:
        return result
    return calculate_indicators(result)


def build_timeframes(base: pd.DataFrame, base_interval: str):
    frames = {"Source": base}
    rules = {
        "M5": "5min",
        "M15": "15min",
        "M30": "30min",
        "H1": "1h",
        "H4": "4h",
        "D1": "1D",
    }

    # Do not resample to a timeframe smaller than the source interval.
    source_minutes = {
        "5m": 5, "15m": 15, "30m": 30, "60m": 60, "1d": 1440
    }.get(base_interval, 5)
    target_minutes = {
        "M5": 5, "M15": 15, "M30": 30,
        "H1": 60, "H4": 240, "D1": 1440
    }

    for label, rule in rules.items():
        if target_minutes[label] < source_minutes:
            continue
        if target_minutes[label] == source_minutes:
            frames[label] = base
        else:
            try:
                sampled = resample_frame(base, rule)
                if not sampled.empty:
                    frames[label] = sampled
            except Exception:
                pass
    return frames


# ---------- ICT-style heuristic labels ----------
def ict_analysis(df: pd.DataFrame) -> dict:
    result = {
        "Bullish Sweep": False,
        "Bearish Sweep": False,
        "Bullish BOS": False,
        "Bearish BOS": False,
        "Bullish FVG": False,
        "Bearish FVG": False,
        "Equal High": False,
        "Equal Low": False,
        "Market Structure": "N/A",
        "Premium/Discount": "N/A",
    }
    if df is None or len(df) < 5:
        return result

    recent = df.tail(30)
    last = recent.iloc[-1]
    prior = recent.iloc[:-1]
    if prior.empty:
        return result

    prior_high = prior["High"].max()
    prior_low = prior["Low"].min()

    result["Bullish Sweep"] = bool(
        last["Low"] < prior_low and last["Close"] > prior_low
    )
    result["Bearish Sweep"] = bool(
        last["High"] > prior_high and last["Close"] < prior_high
    )
    result["Bullish BOS"] = bool(last["Close"] > prior_high)
    result["Bearish BOS"] = bool(last["Close"] < prior_low)

    # Three-candle gap heuristics.
    if len(recent) >= 3:
        first = recent.iloc[-3]
        third = recent.iloc[-1]
        result["Bullish FVG"] = bool(third["Low"] > first["High"])
        result["Bearish FVG"] = bool(third["High"] < first["Low"])

    tolerance = max(float(last["Close"]) * 0.0005, 0.01)
    result["Equal High"] = bool(
        (prior["High"].max() - prior["High"].min()) <= tolerance
    )
    result["Equal Low"] = bool(
        (prior["Low"].max() - prior["Low"].min()) <= tolerance
    )

    if result["Bullish BOS"]:
        result["Market Structure"] = "Bullish break heuristic"
    elif result["Bearish BOS"]:
        result["Market Structure"] = "Bearish break heuristic"
    else:
        result["Market Structure"] = "No clear break"

    dealing_range = prior_high - prior_low
    midpoint = prior_low + dealing_range / 2
    if last["Close"] > midpoint:
        result["Premium/Discount"] = "Premium zone (range heuristic)"
    elif last["Close"] < midpoint:
        result["Premium/Discount"] = "Discount zone (range heuristic)"
    else:
        result["Premium/Discount"] = "Equilibrium"

    return result


# ---------- Optional saved model ----------
@st.cache_resource(show_spinner=False)
def load_ai_model():
    try:
        import joblib
    except Exception:
        return None, "joblib package পাওয়া যায়নি।"

    candidates = [
        Path("XAUUSD_HYBRID_PROJECT") / "XAUUSD_AI_Model.pkl",
        Path("XAUUSD_AI_Model.pkl"),
        Path("forex_ai_model.pkl"),
    ]
    for path in candidates:
        if path.exists():
            try:
                return joblib.load(path), f"Loaded: {path.as_posix()}"
            except Exception as exc:
                return None, f"Model load failed: {type(exc).__name__}"
    return None, "Saved model file পাওয়া যায়নি।"

MODEL_FEATURES = [
    "EMA_20", "EMA_50", "EMA_200", "RSI", "MACD", "MACD_Signal",
    "ATR", "Volatility", "Volume_Ratio",
    "Estimated_Buy_Pressure", "Estimated_Sell_Pressure",
]


def get_model_result(df: pd.DataFrame):
    model, status = load_ai_model()
    if model is None:
        return None, status

    try:
        row = df[MODEL_FEATURES].tail(1).replace([np.inf, -np.inf], np.nan)
        if row.isna().any().any():
            row = row.fillna(0)
        prediction = model.predict(row)[0]
        score_text = "ক্লাসিফিকেশন ফলাফল পাওয়া গেছে"
        class_scores = None

        if hasattr(model, "predict_proba"):
            probs = model.predict_proba(row)[0]
            classes = getattr(model, "classes_", None)
            if classes is None and hasattr(model, "named_steps"):
                final_estimator = list(model.named_steps.values())[-1]
                classes = getattr(final_estimator, "classes_", None)
            if classes is not None:
                class_scores = {
                    str(cls): float(prob)
                    for cls, prob in zip(classes, probs)
                }

        return {
            "prediction": str(prediction),
            "scores": class_scores,
            "note": score_text,
        }, status
    except Exception as exc:
        return None, f"Model inference failed: {type(exc).__name__}"


# ---------- News ----------
@st.cache_data(ttl=900, show_spinner=False)
def get_news():
    feeds = [
        "https://news.google.com/rss/search?q=gold+market+XAUUSD&hl=en-US&gl=US&ceid=US:en"
    ]
    items = []
    for url in feeds:
        try:
            parsed = feedparser.parse(url)
            for entry in parsed.entries[:10]:
                items.append({
                    "title": entry.get("title", "Untitled"),
                    "link": entry.get("link", ""),
                    "published": entry.get("published", ""),
                })
        except Exception:
            continue
    return items


# ---------- Main page ----------
with st.spinner("মার্কেট ডেটা লোড হচ্ছে..."):
    raw = download_market_data(period, interval)

if raw.empty:
    st.error(
        "Yahoo Finance থেকে ডেটা পাওয়া যায়নি। কিছুক্ষণ পর আবার চেষ্টা করো, "
        "অথবা Sidebar থেকে অন্য interval / period বেছে নাও।"
    )
    st.stop()

ticker_used = raw.attrs.get("ticker_used", "Yahoo Finance")
data = calculate_indicators(raw)
timeframes = build_timeframes(data, interval)

latest = data.iloc[-1]
previous = data.iloc[-2] if len(data) > 1 else latest
price_change = float(latest["Close"] - previous["Close"])

m1, m2, m3, m4 = st.columns(4)
m1.metric("সর্বশেষ Close", f"{latest['Close']:,.2f}", f"{price_change:+.2f}")
m2.metric("RSI (14)", f"{latest['RSI']:.2f}")
m3.metric("ATR (14)", f"{latest['ATR']:.2f}" if pd.notna(latest["ATR"]) else "N/A")
m4.metric("Data source", ticker_used)

st.caption(
    f"সর্বশেষ ডেটা সময়: {data.index[-1]} | "
    f"ডেটা interval: {interval} | "
    "Yahoo Finance data may be delayed or unavailable."
)

# ---------- Price chart ----------
st.subheader("📈 XAUUSD Price & Indicators")
chart_data = data.tail(250)
fig = go.Figure()
fig.add_trace(go.Candlestick(
    x=chart_data.index,
    open=chart_data["Open"],
    high=chart_data["High"],
    low=chart_data["Low"],
    close=chart_data["Close"],
    name="Price",
))
for column, label in [
    ("EMA_20", "EMA 20"),
    ("EMA_50", "EMA 50"),
    ("EMA_200", "EMA 200"),
]:
    fig.add_trace(go.Scatter(
        x=chart_data.index,
        y=chart_data[column],
        mode="lines",
        name=label,
    ))
fig.update_layout(
    height=600,
    xaxis_rangeslider_visible=False,
    template="plotly_dark",
    legend_orientation="h",
    margin=dict(l=10, r=10, t=35, b=10),
)
st.plotly_chart(fig, use_container_width=True)

# ---------- Timeframe overview ----------
st.subheader("🕒 Multi-Timeframe Research")
tf_rows = []
for name, frame in timeframes.items():
    if frame is None or frame.empty:
        continue
    last = frame.iloc[-1]
    if last["Close"] > last["EMA_20"] > last["EMA_50"]:
        bias = "Bullish structure heuristic"
    elif last["Close"] < last["EMA_20"] < last["EMA_50"]:
        bias = "Bearish structure heuristic"
    else:
        bias = "Mixed / sideways"
    tf_rows.append({
        "Timeframe": name,
        "Close": round(float(last["Close"]), 3),
        "EMA 20": round(float(last["EMA_20"]), 3),
        "EMA 50": round(float(last["EMA_50"]), 3),
        "RSI": round(float(last["RSI"]), 2),
        "Research label": bias,
    })
if tf_rows:
    st.dataframe(pd.DataFrame(tf_rows), use_container_width=True, hide_index=True)
else:
    st.info("পর্যাপ্ত timeframe data নেই।")

# ---------- ICT Research ----------
st.subheader("🧭 ICT / Smart Money Research")
available_tf = [name for name in ["M5", "M15", "M30", "H1", "H4", "D1", "Source"] if name in timeframes]
if not available_tf:
    st.warning("ICT analysis-এর জন্য timeframe data পাওয়া যায়নি।")
else:
    selected_tf = st.selectbox(
        "ICT timeframe",
        available_tf,
        index=0,
        key="ict_timeframe",
    )
    ict = ict_analysis(timeframes[selected_tf])

    col1, col2, col3 = st.columns(3)
    col1.write(f"**Bullish Liquidity Sweep:** {ict['Bullish Sweep']}")
    col2.write(f"**Bearish Liquidity Sweep:** {ict['Bearish Sweep']}")
    col3.write(f"**Market Structure:** {ict['Market Structure']}")

    col1, col2, col3 = st.columns(3)
    col1.write(f"**Bullish BOS:** {ict['Bullish BOS']}")
    col2.write(f"**Bearish BOS:** {ict['Bearish BOS']}")
    col3.write(f"**Premium / Discount:** {ict['Premium/Discount']}")

    col1, col2, col3 = st.columns(3)
    col1.write(f"**Bullish FVG:** {ict['Bullish FVG']}")
    col2.write(f"**Bearish FVG:** {ict['Bearish FVG']}")
    col3.write(
        f"**Equal High / Low:** {ict['Equal High']} / {ict['Equal Low']}"
    )

st.caption(
    "ICT labels are simplified candle-based heuristics. "
    "They do not verify institutional orders or actual order flow."
)

# ---------- Support / resistance research ----------
st.subheader("📍 Recent Range Levels (Research Only)")
recent = data.tail(100)
support_level = float(recent["Low"].min())
resistance_level = float(recent["High"].max())
s1, s2 = st.columns(2)
s1.metric("Recent range low", f"{support_level:,.2f}")
s2.metric("Recent range high", f"{resistance_level:,.2f}")
st.caption("এগুলো সাম্প্রতিক ডেটার range levels; নিশ্চিত support/resistance নয়।")

# ---------- AI model result ----------
st.subheader("🤖 Saved AI Model — Research Output")
model_result, model_status = get_model_result(data)
st.write(f"Model status: {model_status}")
if model_result is None:
    st.info(
        "AI model output পাওয়া যায়নি। Model file না থাকলে বা training "
        "environment আলাদা হলে এটি স্বাভাবিক।"
    )
else:
    st.write(f"Model class output: **{model_result['prediction']}**")
    if model_result["scores"]:
        st.write("Model class scores (এগুলো win probability নয়):")
        score_frame = pd.DataFrame(
            [
                {"Class": label, "Model score": round(score, 4)}
                for label, score in model_result["scores"].items()
            ]
        )
        st.dataframe(score_frame, use_container_width=True, hide_index=True)
    st.caption(
        "Model output-এর class label ও feature definitions training dataset "
        "দিয়ে যাচাই না করা পর্যন্ত এটিকে নির্ভরযোগ্য signal হিসেবে ধরবে না।"
    )

# ---------- News feed ----------
if show_news:
    st.subheader("📰 Gold Market News")
    news_items = get_news()
    if not news_items:
        st.info("এখন News Feed পাওয়া যাচ্ছে না।")
    else:
        for item in news_items:
            title = item["title"].replace("<", "&lt;").replace(">", "&gt;")
            if item["link"]:
                st.markdown(f"- [{title}]({item['link']})")
            else:
                st.write(f"- {title}")
            if item["published"]:
                st.caption(item["published"])

# ---------- Data table ----------
if show_raw:
    st.subheader("শেষের Market Data")
    st.dataframe(data.tail(100), use_container_width=True)

st.divider()
st.caption(
    "Educational research dashboard only — no broker integration, "
    "no live order execution, and no guarantee of market outcomes."
)
